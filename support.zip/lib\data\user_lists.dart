// lib/data/user_lists.dart
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

enum BookListKind { read, tbr, dnf }

String _keyFor(BookListKind k) => switch (k) {
  BookListKind.read => 'list_read',
  BookListKind.tbr  => 'list_tbr',
  BookListKind.dnf  => 'list_dnf',
};

class UserLists {
  UserLists._();
  static final UserLists instance = UserLists._();

  final Set<String> _read = {};
  final Set<String> _tbr  = {};
  final Set<String> _dnf  = {};

  bool _loaded = false;

  Future<void> load() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    _read
      ..clear()
      ..addAll(_decodeSet(prefs.getString(_keyFor(BookListKind.read))));
    _tbr
      ..clear()
      ..addAll(_decodeSet(prefs.getString(_keyFor(BookListKind.tbr))));
    _dnf
      ..clear()
      ..addAll(_decodeSet(prefs.getString(_keyFor(BookListKind.dnf))));
    _loaded = true;
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyFor(BookListKind.read), jsonEncode(_read.toList()));
    await prefs.setString(_keyFor(BookListKind.tbr),  jsonEncode(_tbr.toList()));
    await prefs.setString(_keyFor(BookListKind.dnf),  jsonEncode(_dnf.toList()));
  }

  Set<String> _decodeSet(String? jsonStr) {
    if (jsonStr == null || jsonStr.isEmpty) return {};
    final data = jsonDecode(jsonStr);
    if (data is List) return data.map((e) => e.toString()).toSet();
    return {};
  }

  bool contains(BookListKind kind, String bookId) {
    final s = _set(kind);
    return s.contains(bookId);
  }

  Future<void> add(BookListKind kind, String bookId) async {
    final s = _set(kind);
    s.add(bookId);
    // enforce exclusivity: one list at a time
    for (final k in BookListKind.values) {
      if (k != kind) _set(k).remove(bookId);
    }
    await _save();
  }

  Future<void> remove(BookListKind kind, String bookId) async {
    _set(kind).remove(bookId);
    await _save();
  }

  Set<String> _set(BookListKind kind) => switch (kind) {
    BookListKind.read => _read,
    BookListKind.tbr  => _tbr,
    BookListKind.dnf  => _dnf,
  };

  // Quick accessors for UI if you want counts later
  int get readCount => _read.length;
  int get tbrCount  => _tbr.length;
  int get dnfCount  => _dnf.length;
}
