// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import '../features/search/trope_search_screen.dart';

class HomeScreen extends StatelessWidget {
  static const route = '/home';
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Welcome back 👋', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.favorite),
              title: const Text('Jump into trope search'),
              subtitle: const Text('Find books by your favorite tropes'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).pushNamed(TropeSearchScreen.route),
            ),
          ),
          Padding(
  padding: const EdgeInsets.only(bottom: 12),
  child: SizedBox(
    width: double.infinity,
    child: ElevatedButton.icon(
      icon: const Icon(Icons.favorite),
      label: const Text('Search by Tropes'),
      onPressed: () => Navigator.of(context).pushNamed(TropeSearchScreen.route),
    ),
  ),
),

          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.local_fire_department_outlined),
              title: const Text('Trending this week'),
              subtitle: const Text('Coming soon'),
            ),
          ),
        ],
      ),
    );
  }
}
