// lib/data/book.dart
import 'dart:convert';

class Book {
  final String id; // stable key: title|author (lowercase) if no isbn13
  final String title;
  final String author;
  final String? isbn13;
  final String? blurb;            // renamed from description
  final int? pageCount;
  final String? publishedDate;
  final List<String> tropes;
  final List<String> subgenres;
  final String? coverUrl;

  // ignore: prefer_typing_uninitialized_variables
  var cover;         // can be 'assets/…', http(s), or null

  Book({
    required this.id,
    required this.title,
    required this.author,
    this.isbn13,
    this.blurb,
    this.pageCount,
    this.publishedDate,
    required this.tropes,
    required this.subgenres,
    this.coverUrl,
  });

  static String _s(dynamic v) => v == null ? '' : v.toString();
  static int? _i(dynamic v) {
    if (v == null) return null;
    final s = v.toString().trim();
    return s.isEmpty ? null : int.tryParse(s);
  }
  static List<String> _csv(dynamic v) {
    final s = _s(v).trim();
    if (s.isEmpty || s.toLowerCase() == 'none') return const [];
    return s.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  }

  factory Book.fromMap(Map<String, dynamic> m) {
    final title = (_s(m['title']).isNotEmpty ? _s(m['title']) : _s(m['original_title'])).trim();
    final author = _s(m['author']).trim();
    final id = (_s(m['isbn13']).trim().isNotEmpty)
        ? _s(m['isbn13']).trim()
        : '${title.toLowerCase()}|${author.toLowerCase()}';

    return Book(
      id: id,
      title: title,
      author: author,
      isbn13: _s(m['isbn13']).trim().isEmpty ? null : _s(m['isbn13']).trim(),
      blurb: _s(m['blurb']).trim().isEmpty
          ? (_s(m['description']).trim().isEmpty ? null : _s(m['description']).trim())
          : _s(m['blurb']).trim(),
      pageCount: _i(m['pagecount']),
      publishedDate: _s(m['publisheddate']).trim().isEmpty ? null : _s(m['publisheddate']).trim(),
      tropes: _csv(m['tropes']),
      subgenres: _csv(m['subgenres']),
      coverUrl: _s(m['cover_url']).trim().isEmpty ? null : _s(m['cover_url']).trim(),
    );
  }

  get description => null;

  static List<Book> listFromJsonString(String jsonStr) {
    final data = json.decode(jsonStr);
    if (data is List) {
      return data.map((e) => Book.fromMap(e as Map<String, dynamic>)).toList();
    }
    return const [];
  }
}
