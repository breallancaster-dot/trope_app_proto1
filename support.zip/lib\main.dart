// lib/main.dart
import 'package:flutter/material.dart';
import 'navigation/app_shell.dart';

// add these imports for the routes you want to navigate to
import 'features/search/trope_search_screen.dart';
import 'screens/book_detail_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BookApp());
}

class BookApp extends StatelessWidget {
  const BookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Trope App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF6C63FF),
      ),
      home: const AppShell(),
      routes: {
        // register any screens you want to push by name:
        TropeSearchScreen.route: (_) => const TropeSearchScreen(),
        BookDetailScreen.route: (_) => const BookDetailScreen(),
      },
    );
  }
}
