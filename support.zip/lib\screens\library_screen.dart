// lib/screens/library_screen.dart
import 'package:flutter/material.dart';

class LibraryScreen extends StatelessWidget {
  static const route = '/library';
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Library')),
      body: const Center(
        child: Text('Your Library (Read / TBR / DNF) — coming soon'),
      ),
    );
  }
}
