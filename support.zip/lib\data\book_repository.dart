// lib/data/book_repository.dart
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'book.dart';

class BookRepository {
  BookRepository._();
  static final BookRepository _singleton = BookRepository._();
  static BookRepository get I => _singleton; // usage: BookRepository.I

  bool _loaded = false;
  final List<Book> _books = [];
  final Map<String, Book> _byId = {};
  final Map<String, Set<String>> _tropeIndex = {}; // trope -> set<bookId>
  final Set<String> _allTropes = {};

  // ignore: prefer_typing_uninitialized_variables
  static var instance;

  bool get isLoaded => _loaded;
  List<Book> get books => List.unmodifiable(_books);
  Set<String> get allTropes => Set.unmodifiable(_allTropes);

  Future<void> load() async {
    if (_loaded) return;
    final raw = await rootBundle.loadString('assets/data/final_books.json');
    final List<dynamic> arr = json.decode(raw) as List<dynamic>;
    for (final e in arr) {
      final b = Book.fromMap(e as Map<String, dynamic>);
      _books.add(b);
      _byId[b.id] = b;
      for (final t in b.tropes) {
        final key = t.toLowerCase();
        _allTropes.add(t);
        _tropeIndex.putIfAbsent(key, () => <String>{}).add(b.id);
      }
    }
    _books.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    _loaded = true;
  }

  // Simple text search over title/author.
  List<Book> searchByQuery(String q) {
    final qq = q.trim().toLowerCase();
    if (qq.isEmpty) return books;
    return _books.where((b) =>
      b.title.toLowerCase().contains(qq) ||
      b.author.toLowerCase().contains(qq)
    ).toList();
  }

  // Trope helpers (for the trope screen later)
  Set<String> bookIdsForSelectedTropes(List<String> selected) {
    if (selected.isEmpty) return _byId.keys.toSet();
    Set<String>? acc;
    for (final s in selected) {
      final ids = _tropeIndex[s.toLowerCase()] ?? <String>{};
      acc = (acc == null) ? {...ids} : acc.intersection(ids);
      if (acc.isEmpty) break;
    }
    return acc ?? <String>{};
  }

  Set<String> viableNextTropes(List<String> selected) {
    final currentIds = bookIdsForSelectedTropes(selected);
    if (currentIds.isEmpty) return <String>{};
    final counts = <String, int>{};
    for (final id in currentIds) {
      final b = _byId[id];
      if (b == null) continue;
      for (final t in b.tropes) {
        final tlc = t.toLowerCase();
        if (!selected.map((e) => e.toLowerCase()).contains(tlc)) {
          counts[tlc] = (counts[tlc] ?? 0) + 1;
        }
      }
    }
    return counts.entries.where((e) => e.value > 0).map((e) => e.key).toSet();
  }

  List<Book> booksByIds(Set<String> ids) =>
      ids.map((id) => _byId[id]).whereType<Book>().toList();
}
