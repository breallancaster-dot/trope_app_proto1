// lib/screens/book_detail_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';

import '../data/book.dart';
import '../data/book_repository.dart';

class BookDetailScreen extends StatefulWidget {
  static const route = '/book-detail';
  const BookDetailScreen({super.key});

  @override
  State<BookDetailScreen> createState() => _BookDetailScreenState();
}

class _BookDetailScreenState extends State<BookDetailScreen> {
  bool _loading = true;
  Book? _book;
  bool _didReadArgs = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_didReadArgs) {
      _didReadArgs = true;
      _load();
    }
  }

  Future<void> _load() async {
    final args = ModalRoute.of(context)?.settings.arguments;
    final id = (args is Map && args['id'] is String) ? args['id'] as String : null;

    final repo = BookRepository.instance;
    await repo.load(); // no-op if already loaded

    Book? b;

    // Prefer a direct method if present
    try {
      final dynamic maybe = (repo as dynamic).bookById;
      if (maybe is Function && id != null) {
        b = maybe(id) as Book?;
      }
    } catch (_) {
      // ignore
    }

    // Fallback: filter from a set
    if (b == null && id != null) {
      final list = repo.booksByIds({id});
      if (list.isNotEmpty) b = list.first;
    }

    setState(() {
      _book = b;
      _loading = false;
    });
  }

  Widget _coverWidget(Book b) {
    final url = b.coverUrl ?? '';
    const w = 120.0, h = 180.0;

    Widget fallback() => Container(
          width: w,
          height: h,
          color: Colors.black12,
          child: const Icon(Icons.menu_book, size: 32, color: Colors.black45),
        );

    if (url.isEmpty) return fallback();

    if (url.startsWith('http')) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.network(
          url,
          width: w,
          height: h,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => fallback(),
        ),
      );
    } else {
      try {
        return ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.file(
            File(url),
            width: w,
            height: h,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => fallback(),
          ),
        );
      } catch (_) {
        return fallback();
      }
    }
  }

  Widget _infoRow(IconData icon, String label, String value) {
    if (value.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(color: Colors.black87),
                children: [
                  TextSpan(
                    text: '$label: ',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  TextSpan(text: value),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _chips(String title, List<String> items, Color bg, Color fg) {
    if (items.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        ),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: items
              .map((t) => Chip(
                    label: Text(t),
                    backgroundColor: bg,
                    labelStyle: TextStyle(color: fg),
                  ))
              .toList(),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Book')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_book == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Book')),
        body: const Center(child: Text('Book not found')),
      );
    }

    final b = _book!;

    return Scaffold(
      appBar: AppBar(
        title: Text(b.title, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'Add to Read',
            icon: const Icon(Icons.check_circle_outline),
            onPressed: () {
              // TODO: hook to reading list
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text('Added to Read (placeholder)')));
            },
          ),
          IconButton(
            tooltip: 'Add to TBR',
            icon: const Icon(Icons.bookmark_add_outlined),
            onPressed: () {
              // TODO: hook to TBR
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text('Added to TBR (placeholder)')));
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _coverWidget(b),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(b.title,
                        style: theme.textTheme.titleLarge,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text(
                      b.author,
                      style: theme.textTheme.titleMedium!
                          .copyWith(color: theme.colorScheme.primary),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 12),
                    _infoRow(Icons.numbers, 'ISBN-13', b.isbn13 ?? ''),
                    _infoRow(Icons.menu_book_outlined, 'Pages', b.pageCount?.toString() ?? ''),
                    _infoRow(Icons.event, 'Published', b.publishedDate ?? ''),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          _chips(
            'Tropes',
            b.tropes,
            theme.colorScheme.secondaryContainer,
            theme.colorScheme.onSecondaryContainer,
          ),
          const SizedBox(height: 12),
          _chips(
            'Subgenres',
            b.subgenres,
            theme.colorScheme.tertiaryContainer,
            theme.colorScheme.onTertiaryContainer,
          ),
          const SizedBox(height: 16),

          if ((b.description ?? '').trim().isNotEmpty) ...[
            Text('Blurb', style: theme.textTheme.titleMedium),
            const SizedBox(height: 6),
            _ExpandableText(b.description!.trim(), 6), // <-- pass trimLines
          ],
        ],
      ),
    );
  }
}

class _ExpandableText extends StatefulWidget {
  final String text;
  final int trimLines;
  // ignore: unused_element_parameter
  const _ExpandableText(this.text, this.trimLines, {super.key});

  @override
  State<_ExpandableText> createState() => _ExpandableTextState();
}

class _ExpandableTextState extends State<_ExpandableText> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textWidget = Text(
      widget.text,
      maxLines: _expanded ? null : widget.trimLines,
      overflow: _expanded ? TextOverflow.visible : TextOverflow.ellipsis,
      textAlign: TextAlign.start,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        textWidget,
        const SizedBox(height: 4),
        TextButton(
          onPressed: () => setState(() => _expanded = !_expanded),
          child: Text(
            _expanded ? 'Show less' : 'Read more',
            style: TextStyle(color: theme.colorScheme.primary),
          ),
        ),
      ],
    );
  }
}
