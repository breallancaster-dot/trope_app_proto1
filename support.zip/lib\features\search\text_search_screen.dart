// lib/features/search/text_search_screen.dart
import 'package:flutter/material.dart';
import '../../data/book_repository.dart';
import '../../data/book.dart';

class TextSearchScreen extends StatefulWidget {
  const TextSearchScreen({super.key});

  @override
  State<TextSearchScreen> createState() => _TextSearchScreenState();
}

class _TextSearchScreenState extends State<TextSearchScreen> {
  bool _loading = true;
  List<Book> _results = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await BookRepository.I.load();
    setState(() {
      _loading = false;
      _results = BookRepository.I.searchByQuery('');
    });
  }

  void _onQuery(String v) {
    setState(() {
      _results = BookRepository.I.searchByQuery(v);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: TextField(
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search),
              hintText: 'Search by title or author',
              border: OutlineInputBorder(),
            ),
            onChanged: _onQuery,
          ),
        ),
        Expanded(
          child: _results.isEmpty
              ? const Center(child: Text('No results'))
              : ListView.separated(
                  itemCount: _results.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final b = _results[i];
                    return ListTile(
                      title: Text(b.title),
                      subtitle: Text('${b.author}${b.tropes.isNotEmpty ? ' • ${b.tropes.join(', ')}' : ''}'),
                      // You can add a tiny cover later.
                      onTap: () {}, // TODO: book detail
                    );
                  },
                ),
        ),
      ],
    );
  }
}
