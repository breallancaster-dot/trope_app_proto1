// lib/features/search/trope_search_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';

import '../../data/book.dart';
import '../../data/book_repository.dart';
import '../../screens/book_detail_screen.dart';

class TropeSearchScreen extends StatefulWidget {
  static const route = '/trope-search';
  const TropeSearchScreen({super.key});

  @override
  State<TropeSearchScreen> createState() => _TropeSearchScreenState();
}

class _TropeSearchScreenState extends State<TropeSearchScreen> {
  bool _loading = true;

  // source
  List<String> _allTropes = [];

  // selection + computed state
  final List<String> _selected = [];
  Set<String> _viableNext = {};
  List<Book> _matchingBooks = [];

  // optional string filter (title/author)
  String _query = "";

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    final repo = BookRepository.instance;
    await repo.load(); // no-op if already loaded
    _allTropes = repo.allTropes()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    _recompute();
    setState(() => _loading = false);
  }

  void _recompute() {
    final repo = BookRepository.instance;

    // Which books match current selection
    final ids = repo.bookIdsForSelectedTropes(_selected);
    var books = repo.booksByIds(ids);

    // Title/author filter
    if (_query.trim().isNotEmpty) {
      final q = _query.toLowerCase().trim();
      books = books.where((b) =>
          b.title.toLowerCase().contains(q) || b.author.toLowerCase().contains(q)).toList();
    }

    // Stable sort
    books.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));

    // Which next tropes are still viable given the selected set
    _viableNext = repo.viableNextTropes(_selected);

    _matchingBooks = books;
  }

  void _toggleTrope(String trope) {
    setState(() {
      if (_selected.contains(trope)) {
        _selected.remove(trope);
      } else {
        if (_selected.length >= 5) return; // hard cap
        _selected.add(trope);
      }
      _recompute();
    });
  }

  void _clearAll() {
    setState(() {
      _selected.clear();
      _query = "";
      _recompute();
    });
  }

  bool _isDisabledChip(String trope) {
    if (_selected.contains(trope)) return false;      // selected chips stay enabled
    if (_selected.length >= 5) return true;           // cap reached
    return !_viableNext.contains(trope.toLowerCase()); // cannot add if it leads to zero matches
  }

  Widget _coverThumb(Book b) {
    final url = b.coverUrl ?? "";
    const w = 48.0, h = 72.0;

    Widget fallback() => Container(
          width: w,
          height: h,
          color: Colors.black12,
        );

    if (url.isEmpty) return fallback();

    if (url.startsWith('http')) {
      return Image.network(
        url,
        width: w,
        height: h,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => fallback(),
      );
    } else {
      // local absolute path
      try {
        return Image.file(
          File(url),
          width: w,
          height: h,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => fallback(),
        );
      } catch (_) {
        return fallback();
      }
    }
  }

  Widget _buildChip(String trope) {
    final selected = _selected.contains(trope);
    final disabled = _isDisabledChip(trope);

    return FilterChip(
      label: Text(
        trope,
        style: TextStyle(
          color: disabled
              ? Colors.grey.shade500
              : (selected ? Colors.white : null),
        ),
      ),
      selected: selected,
      onSelected: disabled ? null : (_) => _toggleTrope(trope),
      backgroundColor: disabled ? Colors.grey.shade200 : null,
      selectedColor: Theme.of(context).colorScheme.primary,
      checkmarkColor: selected ? Colors.white : null,
      shape: StadiumBorder(
        side: BorderSide(
          color: disabled
              ? Colors.grey.shade300
              : Theme.of(context).colorScheme.outlineVariant,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Search by Tropes')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final resultCount = _matchingBooks.length;
    final maxReached = _selected.length >= 5;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Search by Tropes'),
        actions: [
          if (_selected.isNotEmpty || _query.isNotEmpty)
            TextButton.icon(
              onPressed: _clearAll,
              icon: const Icon(Icons.clear_all),
              label: const Text('Clear'),
              style: TextButton.styleFrom(
                foregroundColor: theme.colorScheme.onPrimary,
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Optional text filter
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Filter by title or author (optional)',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => setState(() {
                _query = v;
                _recompute();
              }),
            ),
          ),

          // Selection header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                Text(
                  _selected.isEmpty
                      ? 'Select up to 5 tropes'
                      : 'Selected (${_selected.length}/5)',
                  style: theme.textTheme.bodyMedium!
                      .copyWith(fontWeight: FontWeight.w600),
                ),
                const Spacer(),
                if (maxReached)
                  Text(
                    'Max selected',
                    style: theme.textTheme.bodySmall!
                        .copyWith(color: theme.colorScheme.secondary),
                  ),
              ],
            ),
          ),

          // Trope chips
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _allTropes.map(_buildChip).toList(),
              ),
            ),
          ),

          const Divider(height: 16),

          // Results header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Row(
              children: [
                Text(
                  '$resultCount result${resultCount == 1 ? '' : 's'}',
                  style: theme.textTheme.titleMedium,
                ),
                const Spacer(),
                if (_selected.isNotEmpty)
                  Flexible(
                    child: Text(
                      _selected.join(' • '),
                      style: theme.textTheme.bodySmall!
                          .copyWith(color: theme.colorScheme.outline),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                  ),
              ],
            ),
          ),

          // Results list
          Expanded(
            child: resultCount == 0
                ? const Center(child: Text('No books match the current selection.'))
                : ListView.separated(
                    padding: const EdgeInsets.only(bottom: 16),
                    itemCount: _matchingBooks.length,
                    separatorBuilder: (_, __) =>
                        Divider(height: 1, color: theme.dividerColor),
                    itemBuilder: (context, i) {
                      final b = _matchingBooks[i];
                      return ListTile(
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: _coverThumb(b),
                        ),
                        title: Text(b.title),
                        subtitle: Text(
                          '${b.author}${b.tropes.isNotEmpty ? ' • ${b.tropes.join(', ')}' : ''}',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        onTap: () {
                          Navigator.of(context).pushNamed(
                            BookDetailScreen.route,
                            arguments: {'id': b.id},
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
