// lib/auth/session.dart
import 'package:shared_preferences/shared_preferences.dart';

class Session {
  static const _kSignedIn = 'signed_in';
  static const _kUserEmail = 'user_email';

  static Future<bool> isSignedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_kSignedIn) ?? false;
  }

  static Future<void> signIn({required String email}) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kSignedIn, true);
    await prefs.setString(_kUserEmail, email);
  }

  static Future<void> continueAsGuest() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kSignedIn, true);
    await prefs.remove(_kUserEmail);
  }

  static Future<void> signOut() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kSignedIn, false);
    await prefs.remove(_kUserEmail);
  }

  static Future<String?> currentEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kUserEmail);
  }
}
